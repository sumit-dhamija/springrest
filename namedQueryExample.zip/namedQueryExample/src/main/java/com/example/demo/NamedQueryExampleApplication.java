package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.dao.CompanyDao;
import com.example.demo.dao.EmployeeDao;
import com.example.demo.entity.Company;
import com.example.demo.entity.Employee;

@SpringBootApplication
public class NamedQueryExampleApplication implements CommandLineRunner {

	@Autowired
	CompanyDao companyDao;
	
	@Autowired
	EmployeeDao employeeDao;
	
	public static void main(String[] args) {
		SpringApplication.run(NamedQueryExampleApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		List<Employee> emps = employeeDao.searchByName("Raj_ev");
		emps.forEach(e -> System.out.println(e.getName()));
//		Company company = companyDao.companyWithDepartmentsAndEmployeesAndOfficesNamedQuery(1L);
//		System.out.println(company.getName());
//		company.getDepartments().stream().forEach(d -> System.out.println(d.getName()));
	}
}

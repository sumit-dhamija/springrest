package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Service;

@Service
public class RedisService {
	@Autowired
    private RedisTemplate redisTemplate;
    public void printDetails() {
    	redisTemplate.setKeySerializer( new StringRedisSerializer() );
    	 ValueOperations values = redisTemplate.opsForValue();
         values.set("books::isbn-9011", new Book("isbn-9011", "Java"));
//    	redisTemplate.keys("books*").forEach(System.out::println);
    	System.out.println("***********");
    	redisTemplate.keys("books*").forEach(key -> {
    		Book b = (Book) values.get(key);
    		System.out.println(key + " =========> " + b.getTitle());
    	});
    }
}

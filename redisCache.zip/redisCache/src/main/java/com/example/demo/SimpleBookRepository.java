package com.example.demo;

import java.util.Arrays;
import java.util.List;

import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
@CacheConfig(cacheNames = "books")
public class SimpleBookRepository implements BookRepository {
	static List<Book> books = Arrays.asList(new Book("isbn-1234", "First Book"), new Book("isbn-4567", "Second Book"), new Book("isbn-4567", "Second Book") );
	
	@Override
	@Cacheable( key="#isbn")
	public Book getByIsbn(String isbn) {
		simulateSlowService();
		return books.stream().filter(b -> b.getIsbn().equals(isbn)).findFirst().get();
	}

	@CachePut(key="#isbn")
	public Book updateBook(String isbn, String title) {
		for(int i =0; i < books.size(); i++) {
			Book b = books.get(i);
			if(b.getIsbn().equals(isbn)) {
				b.setTitle(title);
				return b;
			}
		}
		return null;	
	}
	@CacheEvict(cacheNames= {"books"}, allEntries = false, key="#isbn" )
	public void deleteBook(String isbn) {
		
	}
	private void simulateSlowService() {
		try {
			long time = 3000L;
			Thread.sleep(time);
		} catch (InterruptedException e) {
			throw new IllegalStateException(e);
		}
	}

}
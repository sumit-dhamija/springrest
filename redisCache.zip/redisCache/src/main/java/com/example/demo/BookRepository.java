package com.example.demo;

public interface BookRepository {
	Book getByIsbn(String isbn);
	Book updateBook(String isbn, String title);
	void deleteBook(String isbn); 
}

package com.example.demo.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.history.Revision;
import org.springframework.data.history.Revisions;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.ProductDao;
import com.example.demo.entity.Product;

@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	ProductDao productDao;
	
	@PostMapping()
    public @ResponseBody Product saveProduct(@RequestBody Product p) {
        return productDao.save(p);
    }
	
	@PutMapping("/{id}")
	public @ResponseBody Product updateProduct(@PathVariable("id") int id, @RequestBody Product p) {
		Product prd = productDao.findById(id).get();
		prd.setPrice(p.getPrice());
		productDao.save(prd); // CrudRepository save() to Update an Instance
		return prd;
	}
	
	@DeleteMapping("/{id}")
	 public String deleteBook(@PathVariable int id) {
		productDao.deleteById(id);
		return "Product Deleted!!!";
	}
	
	@GetMapping("/lastrevision/{id}")
    public Revision<Integer, Product> getLatestRevisionInfo(@PathVariable  int id){
        return productDao.findLastChangeRevision(id).get();
    }
	
	@GetMapping("/revisions/{id}")
    public Revisions<Integer, Product> getAllRevisionInfo(@PathVariable  int id){
        return productDao.findRevisions(id);
    }
	
}

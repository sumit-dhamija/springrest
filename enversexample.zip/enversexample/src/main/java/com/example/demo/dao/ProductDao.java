package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.history.RevisionRepository;

import com.example.demo.entity.Product;

public interface ProductDao  extends RevisionRepository<Product, Integer, Integer>, JpaRepository<Product, Integer> {

}
